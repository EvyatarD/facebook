var hands = 2;
