var arr =[12,13,14];
